for(i=0;i<=3;i++){
    for(j=3;j>0;j--){
        console.log("hello");
    }
}