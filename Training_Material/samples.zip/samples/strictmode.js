//strictmode 

//var a="xyz";
//"use strict"
//function funCall(){
  //  var b="PQR";
    //console.log(b);


//}
//console.log(a);
//console.log(b);


//4th question ans
//let a="ABAC";
//{
  //  var b="tyui";
    //console.log(b);

//}
//console.log(a);
//console.log(b);


// ans of assignment
var n=1.5;

console.log("number : " ,n,typeof n);