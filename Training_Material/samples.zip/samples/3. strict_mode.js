//"use strict"

// //1. Variale without declaration
// a = "a";
// //2. Same name properties
// // var myobject = {
// //     myproperty1:"B",
// //     myproperty1:"A"
// // }


// // console.log(myobject.myproperty1);

// //strict mode inside function

// function func1() {
//     "use strict"
//     //b = "a"
// }

