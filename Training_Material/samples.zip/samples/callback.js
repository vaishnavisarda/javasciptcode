a(function read(b) {
    
});

function a(callback) {
    callback()
}