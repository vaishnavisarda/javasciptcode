var  arr[i];
var array=arr[`1,2,3,4,5,6,7,8,9,10`]

if(arr[i]==0)
{
    console.log([i] =even);
    i++;
}
else {
    console.log([i] =odd);
}
/*In JavaScript, use any of the single or double quotes for a string. 
However, you should be consistent in whatever you select.
 Single and double quotes are the same in JavaScript −

"Let us say: \"Life's good!\""
'Let us say: "Life\'s good!"'
“Let us say: \"Life\'s good!\""
'Let us say: \"Life\'s good!\"'*/