let num = 5; //num -> 0001 | 5
let num1 = num; // num1 -> 0002 | 5

num++;
console.log(num);
console.log(num1);

num1++;
console.log(num);
console.log(num1);

let obj = new Object(); // obj -> 0001 | {}
//let obj = {};

let obj2 = obj; // obj2 -> 0001 

obj.name = "Object";
console.log(obj.name);
console.log(obj2.name);

obj2.name = "Object2";
console.log(obj.name);
console.log(obj2.name);

function passByValue(arg) {
    //let arg = value;
    arg++;
    console.log(arg);
    return;
}

function passByReference(arg) {
    arg.value++;
    console.log(arg.value);
    return;
}

function newReference(arg) {
    //let arg = object
    arg.value++;//0006 | {value: 2}
    arg = new Object();//arg -> 0007 | {value : 11}
    arg.value = 10;
    arg.value++;
    console.log(arg.value);
    return;
}

let value = 1;//0004 | 1
let object = {
    value: 1
}; // 0006 | {value:1}
//arg = value;
passByValue(value);//arg -> 0005 | 2
console.log(value);
//arg = object
passByReference(object);//arg -> 0006
console.log(object.value);
//arg = object
newReference(object);//arg -> 0006
console.log(object.value);

let str = "this is a string";
str.name = "Name of string";
console.log(str.name)

let arr = [4, 5, 6]; // arr -> 0008 | 4|5|6
let arr1 = arr;//arr1 -> 0008

arr1[0] = 10;
console.log(typeof arr);
console.log(arr);
console.log(arr1);
console.log(Array.isArray(arr));
console.log(typeof Date);

let str1 = new String("This ");
str1.name = "some";

console.log(typeof str1);
console.log(str1.name);
console.log(str1 instanceof String);
console.log(new Date() instanceof Date);
console.log((new Array()) instanceof Array);