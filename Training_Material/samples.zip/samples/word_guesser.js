let letters=[1,2,3,4,5,6];


// console.log(letters[0]);
// console.log(letters[1]);
// console.log(letters[2]);
// console.log(letters[3]);
// console.log(letters[4]);
for(i=0;i<letters.length;i++){
    
    console.log(letters[i]);
}

