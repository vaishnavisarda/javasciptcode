let val="*";

    
    for(let i=0;i<=5;i++){
      val=val+"*";
      console.log(val);
    }
   