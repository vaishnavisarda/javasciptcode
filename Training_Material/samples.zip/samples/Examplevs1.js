//Store the following into variables: number of children, 
//partner's name, geographic location, job title.

let no_of_childrens=2;
let part_name= "Sumit";
let geog_loc="Pune";
let job_title="Engineer";

console.log(no_of_childrens);
console.log(part_name);
console.log(geog_loc);
console.log(job_title);