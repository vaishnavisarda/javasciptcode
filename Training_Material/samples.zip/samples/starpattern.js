let i="*";
for(j=0;j<=5;j++){
    for(k=5;k>0;k--){
        console.log(i)
        }

  
    }